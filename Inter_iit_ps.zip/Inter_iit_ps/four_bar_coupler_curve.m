function four_bar_coupler_curve()
% ---- Example link lengths (Grashof Crank-Rocker) ----
l = 1000;   % AB - frame (Ground)
s = 250;    % AD - crank / input
p = 600;    % DC - coupler
q = 700;    % CB - rocker
m = 1000;    % DE - coupler triangle side 1
n = 700;    % CE - coupler triangle side 2

% Grashof condition checks
links = [s, l, p, q];
assert(s == min(links), 'AD (s) must be the shortest of s, l, p, q');
assert(l == max(links), 'AB (l) must be the longest of s, l, p, q');
assert(s + l < p + q, 'Grashof crank-rocker condition s + l < p + q failed');

% Compute coupler curve points
out = calculate_coupler_curve(l, s, p, q, m, n, 721);

% ---- Plotting ----
figure('Position', [100, 100, 700, 700]);
hold on; grid on; axis equal;

plot(out.Ex, out.Ey, 'b-', 'LineWidth', 1.8, 'DisplayName', 'Coupler curve (E)');
plot(out.Dx, out.Dy, 'r--', 'LineWidth', 1.0, 'Color', [1 0 0 0.35], 'DisplayName', 'Path of D');
plot(out.Cx, out.Cy, 'g--', 'LineWidth', 1.0, 'Color', [0 0.5 0 0.35], 'DisplayName', 'Path of C');
plot(0, 0, 'ks', 'MarkerSize', 8, 'MarkerFaceColor', 'k', 'DisplayName', 'A (fixed pivot)');
plot(l, 0, 'k^', 'MarkerSize', 8, 'MarkerFaceColor', 'k', 'DisplayName', 'B (fixed pivot)');

title('Four-bar linkage: coupler curve traced by point E');
xlabel('x'); ylabel('y');
legend('Location', 'northeast');
hold off;
end

function out = calculate_coupler_curve(l, s, p, q, m, n, num_points)
thetas = linspace(0, 2 * pi, num_points);

Ax = 0.0; Ay = 0.0;
Bx = l;   By = 0.0;

% Constant angle (beta) inside rigid triangle D-C-E at vertex D
cos_beta = (p^2 + m^2 - n^2) / (2 * p * m);
cos_beta = max(-1.0, min(1.0, cos_beta)); % Clamp values
beta = acos(cos_beta);

Dx = s * cos(thetas);
Dy = s * sin(thetas);

d = sqrt(l^2 + s^2 - 2 * l * s * cos(thetas));

% theta1: angle ABD (at B, between BA and BD)
theta1 = atan2(s * sin(thetas), l - s * cos(thetas));

% theta2: angle DBC (at B, between BD and BC)
cos_t2 = (q^2 + d.^2 - p^2) ./ (2 * q * d);
cos_t2 = max(-1.0, min(1.0, cos_t2)); % Clamp values
theta2 = acos(cos_t2);

% Global direction B->C, then position of C
ang_BC = (pi - theta1) - theta2;
Cx = Bx + q * cos(ang_BC);
Cy = By + q * sin(ang_BC);

% Global direction D->C, then rotate by beta for D->E
ang_DC = atan2(Cy - Dy, Cx - Dx);
ang_DE = ang_DC + beta;
Ex = Dx + m * cos(ang_DE);
Ey = Dy + m * sin(ang_DE);

% Store in struct
out.theta = thetas;
out.Ex = Ex; out.Ey = Ey;
out.Dx = Dx; out.Dy = Dy;
out.Cx = Cx; out.Cy = Cy;
end
